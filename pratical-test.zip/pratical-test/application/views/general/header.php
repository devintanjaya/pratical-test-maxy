<html>

	<head>
		<title>Pratical Test Maxy Academy</title>

		<!-- Bootstrap CSS -->
    	<link rel="stylesheet" href="<?= base_url() . 'assets/css/bootstrap.min.css' ?>">

		<!-- jQuery JS -->
	    <script src="<?= base_url() .  'assets/js/jquery.min.js' ?>"></script>

	    <!-- Bootstrap and Popper Bundle JS -->
	    <script src="<?= base_url() .  'assets/js/bootstrap.bundle.min.js' ?>" defer></script>


    	<!-- Datatables CSS -->
	    <!-- <link rel="stylesheet" href="<?php echo base_url()?>assets/css/datatables.min.css"> -->
	    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css" />
  
		<!-- Datatables Js -->
		<!-- <script type="text/javascript"  src="<?php echo base_url()?>assets/js/datatables.min.js"></script> -->
		<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.js"></script>

    	<link rel="stylesheet" href="<?= base_url() . 'assets/css/home.css' ?>">

	</head>

	<body>
